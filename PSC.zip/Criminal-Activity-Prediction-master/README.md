# Criminal-Activity-Prediction
It helps to detect Criminal or Violence Activity using real time Video Surveillance using Camera and alert the concerned person.
It uses detection of suspicious objects, facial expressions and gestures
